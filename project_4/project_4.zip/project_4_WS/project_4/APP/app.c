#include "app.h"
#include "../HAL/lcd.h"
#include "../HAL/led.h"
#include "../HAL/buzzer.h"
#include "../HAL/ultrasonic.h"
#include <avr/io.h>
#include <util/delay.h>
/*Global Variables*/
static uint16 distance = 0;
static uint16 last_distance = 0;

void APP_init(void)
{
    SREG |= (1<<7);   /* Enable global interrupts*/

    LEDS_init();
    Ultrasonic_init();
    Buzzer_init();
    LCD_init();

    LCD_displayString(" Distance=");
}

void APP_update(void)
{
    _delay_ms(50);
    distance = Ultrasonic_readDistance();

    /*only executes if distance changed*/
    if(distance != last_distance)
        {
            LCD_moveCursor(0 ,10);
            LCD_intgerToString(distance);
            LCD_displayString(" cm  ");
            last_distance = distance;
        }


    /* Decision logic */
    if(distance > 20)
    {
        LED_off(RED_LED);
        LED_off(GREEN_LED);
        LED_off(BLUE_LED);
        Buzzer_off();
        LCD_moveCursor(1, 0);
        LCD_displayString("                ");
    }
    else if (distance <= 20 && distance >= 16)
    {
        LED_on(RED_LED);
        LED_off(GREEN_LED);
        LED_off(BLUE_LED);
        Buzzer_off();
        LCD_moveCursor(1, 0);
        LCD_displayString("                ");
    }
    else if (distance <= 15 && distance >= 11)
    {
        LED_on(RED_LED);
        LED_on(GREEN_LED);
        LED_off(BLUE_LED);
        Buzzer_off();
        LCD_moveCursor(1, 0);
        LCD_displayString("                ");
    }
    else if (distance <= 10 && distance >= 6)
    {
        LED_on(RED_LED);
        LED_on(GREEN_LED);
        LED_on(BLUE_LED);
        Buzzer_off();
        LCD_moveCursor(1, 0);
        LCD_displayString("                ");
    }
    else if (distance <= 5 )
    {
        LCD_moveCursor(1 ,6);
        LCD_displayString("Stop ");
        LED_on(RED_LED);
        LED_on(GREEN_LED);
        LED_on(BLUE_LED);
        Buzzer_on();
        _delay_ms(500);
        LED_off(RED_LED);
        LED_off(GREEN_LED);
        LED_off(BLUE_LED);
        Buzzer_off();
    }
}
