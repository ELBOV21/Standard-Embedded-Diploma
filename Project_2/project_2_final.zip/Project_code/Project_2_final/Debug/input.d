input.o input.o: ../input.c ../input.h

../input.h:
