APP/main.o APP/main.o: ../APP/main.c ../APP/../HAL/keypad.h \
  ../APP/../HAL/std_types.h ../APP/../HAL/lcd.h ../APP/std_types.h

../APP/../HAL/keypad.h:

../APP/../HAL/std_types.h:

../APP/../HAL/lcd.h:

../APP/std_types.h:
