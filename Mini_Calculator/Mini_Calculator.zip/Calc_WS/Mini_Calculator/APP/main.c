/*
 * main.c
 *
 *  Created on: Sep 21, 2025
 *      Author: bavly
 */
#include "../HAL/keypad.h"
#include "../HAL/lcd.h"
#include "std_types.h"
#include <string.h>
#include <util/delay.h>
#define CLEAR 13
typedef enum state{INPUT1,OPERATOR_SET,INPUT2,DISPLAYING,ERROR }calc_state;
calc_state state1=INPUT1;
char input_1[6]={0};
char input_2[6]={0};
uint8 index1=0,index2=0;
uint16 a=0,b=0;
uint16 result=0;
uint8 operator=0;
char buf[10]={0};
uint8 error=0;
void Reset_Calc(void)
{
	memset(input_1,0,sizeof(input_1));
	memset(input_2,0,sizeof(input_2));
	memset(buf,0,sizeof(buf));
	index1 =0;
	index2 = 0;
	operator = 0;
	result=0;
	state1 = INPUT1;
	LCD_clearScreen();
}
void display_Result()
{
	itoa(result, buf, 10);
	LCD_clearScreen();
	LCD_displayString(buf);
	strcpy(input_1, buf);
	index1 = strlen(input_1);
	memset(input_2,0,sizeof(input_2));
	index2 = 0;
	operator = 0;
	state1 = DISPLAYING;
}
int main(void)
{
	uint8 key=0;
	LCD_init();
	while(1)
	{
		key=KEYPAD_getPressedKey();
		_delay_ms(200);
		switch(state1)
		{
		case INPUT1 :
			if(key>=0 && key<=9)
			{
				if(index1<5)
				{
					input_1[index1]	='0' + key;
					index1++;
					input_1[index1] = '\0';
					LCD_clearScreen();
					LCD_displayString(input_1);
				}
			}
			else if ((key == '%') || (key == '*') || (key == '+') || (key == '-')  )
			{
				operator =key;
				LCD_clearScreen();
				LCD_displayString(input_1);
				LCD_displayCharacter(operator);
				state1=OPERATOR_SET;
			}
			else if (key == CLEAR)
			{
				Reset_Calc();
			}

			break;
		case OPERATOR_SET:
			if(key>=0 && key<=9)
			{
				input_2[index2]	='0' + key;
				index2++;
				input_2[index2] = '\0';
				LCD_displayString(input_2);
				state1=INPUT2;
			}
			else if (key == CLEAR)
			{
				Reset_Calc();
			}
			break;
		case INPUT2:
			if(key>=0 && key<=9)
			{
				if(index2<5)
				{
					input_2[index2]	='0' + key;
					index2++;
					input_2[index2] = '\0';
					LCD_displayString(input_2);
				}
			}
			else if (key == '=')
			{
				a = atoi(input_1);
				b = atoi(input_2);
				switch(operator)
				{
				case '%':
					if(b==0)
					{
						error=1;
						break;
					}
					result=a/b;
					break;
				case '*':
					result=a*b;
					break;
				case '+':
					result=a+b;
					break;
				case '-':
					result=a-b;
					break;
				}
				if(error)
				{
					LCD_clearScreen();
					LCD_displayString("ERROR");
					state1=ERROR;
					error=0;
				}
				else
				{
					display_Result();
					state1=DISPLAYING;
				}
			}
			else if (key == CLEAR)
			{
				Reset_Calc();
				break;
			}



			break;
		case DISPLAYING:
		case ERROR:
			if(key>=0 && key<=9)
			{
				Reset_Calc();
				if(index1<5)
				{

					input_1[index1]	='0' + key;
					index1++;
					input_1[index1] = '\0';
					LCD_clearScreen();
					LCD_displayString(input_1);
				}
			}
			else if (key == CLEAR)
			{
				Reset_Calc();
			}
			break;

		}

	}

}
