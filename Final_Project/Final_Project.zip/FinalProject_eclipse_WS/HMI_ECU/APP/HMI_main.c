/* ============================================================
 *  HMI_ECU.c
 *  ------------------------------------------------------------
 *  Microcontroller: ATmega32 @ 8MHz
 *
 *  - Provides a menu through LCD and keypad.
 *  - Sends user commands to Control ECU via UART.
 *  - Displays live sensor readings (temperature, distance, window states).
 *  - Retrieves logged faults stored in Control ECU’s EEPROM.
 *  - Uses Timer1 to manage automatic return after display timeout.
 * ============================================================ */

#include "../MCAL/std_types.h"
#include "../HAL/keypad.h"
#include "../HAL/lcd.h"
#include <util/delay.h>
#include "../MCAL/uart.h"
#include "../MCAL/timer.h"
#include <avr/io.h>

/* ====================== ERROR CODES ====================== */
#define P001_ACCIDENT_MIGHT_HAPPENED 0x01   /* Object too close (<10 cm) */
#define P002_ENGINE_HIGH_TEMPERATURE 0x02   /* Temperature > 90°C */
#define UART_RX_TIMEOUT 0xFF                /* Timeout flag for UART receive used for debugging */

/* ====================== TIMER SETTINGS ====================== */
#define DISPLAY_TIMEOUT_TICKS 10   /* 10 seconds */
#define COMPARE_VALUE 7811         /* 1 second tick at 8MHz / 1024 prescaler */

/* ====================== SYSTEM STATES ====================== */
typedef enum {
	IDLE,               // Display main menu */
	START_OPERATION,    /* Start monitoring mode */
	DISPLAY_VALUES,     /* Show live sensor readings */
	ERROR_RETRIEVAL,    /* Display logged faults */
	STOP_MONITORING     /* Stop monitoring */
} state;
/* ====================== GLOBAL VARIABLES ====================== */
volatile state System_state = IDLE;
volatile uint8 tick_count = 0;
volatile uint8 timeout_flag = 0;
/* ====================== MODULE CONFIGURATION ====================== */
UART_ConfigType uart_config = {EIGHT_BIT_DATA, NO_PARITY, ONE_STOP_BIT, BAUD_9600};
Timer_ConfigType timer1_config = {0, COMPARE_VALUE, TIMER1_ID, CLK_1024, TIMER_MODE_COMPARE};

/* ============================================================
 * Function: Timer_Callback
 * Purpose : Called each 1 second by Timer1 ISR.
 *           Sets timeout flag after DISPLAY_TIMEOUT_TICKS.
 * ============================================================ */
void Timer_Callback(void) {
	tick_count++;
	if(tick_count >= DISPLAY_TIMEOUT_TICKS) {
		tick_count = 0;
		Timer_deInit(TIMER1_ID);
		timeout_flag = 1; /* Signal the main loop that time is up */
	}
}

/* ============================================================
 * Function: DisplayMenu
 * Purpose : Displays the main menu on LCD.
 * ============================================================ */
void DisplayMenu(void) {
	LCD_clearScreen();
	LCD_displayStringRowColumn(0,0,"1.Start");
	LCD_displayStringRowColumn(1,0,"2.Display Values");
	LCD_displayStringRowColumn(2,0,"3.Display Faults");
	LCD_displayStringRowColumn(3,0,"4.Stop");
}

/* ============================================================
 * Function: receive_byte_timeout
 * Purpose : Non-blocking UART receive with timeout .
 * Returns : 1 if byte received, 0 if timeout occurred.
 * ============================================================ */
uint8 receive_byte_timeout(uint8 *out, uint16 timeout_ms)
{
	uint16 elapsed = 0;
	while(elapsed < timeout_ms)
	{
		if(UART_recieveByteNonBlocking(out))
			return 1;
		_delay_ms(1);
		elapsed++;
	}
	*out = UART_RX_TIMEOUT; // Assign timeout error code
	return 0;
}


/* ============================================================
 * Function: DisplayAgainPrompt
 * Purpose : After displaying data or faults, asks user whether
 *           to repeat the display or return to main menu.
 * Note    : Blocking function – waits for key press.
 * ============================================================ */
void DisplayAgainPrompt(state from_state) {
	LCD_clearScreen();
	LCD_displayString("Display again?");
	if(from_state == DISPLAY_VALUES)
		LCD_displayStringRowColumn(1,0,"2=YES Other=MENU");
	else
		LCD_displayStringRowColumn(1,0,"3=YES Other=MENU");

	uint8 key = 0;
	/* Loop until a key is pressed */
	while( (key = KEYPAD_getPressedKey()) == 0 ) {
		_delay_ms(50);
	}
	/*Handle user Choice*/
	if(from_state == DISPLAY_VALUES && key == 2) {
		System_state = DISPLAY_VALUES;
		tick_count = 0;
		timeout_flag = 0;
		Timer_init(&timer1_config);
	} else if(from_state == ERROR_RETRIEVAL && key == 3) {
		System_state = ERROR_RETRIEVAL;
		tick_count = 0;
		timeout_flag = 0;
		Timer_init(&timer1_config);
	} else {
		System_state = IDLE;
	}
}

/* ============================================================
 * Function: HandleIdleState
 * Purpose : Wait for user to select from main menu using keypad.
 * ============================================================ */
void HandleIdleState(void) {
	static uint8 menu_displayed = 0;

	if(!menu_displayed) {
		DisplayMenu();
		menu_displayed = 1;
	}

	uint8 key = KEYPAD_getPressedKey();
	if(key) {
		menu_displayed = 0; /* Menu will be redrawn when returning to IDLE */
		Timer_deInit(TIMER1_ID); /* Stop timer if it was somehow running */
		tick_count = 0;
		timeout_flag = 0;

		switch(key) {
		case 1:
			System_state = START_OPERATION;
			break;
		case 2:
			System_state = DISPLAY_VALUES;
			Timer_init(&timer1_config); /* Start 10-sec timer */
			break;
		case 3:
			System_state = ERROR_RETRIEVAL;
			Timer_init(&timer1_config); /* Start 10-sec timer */
			break;
		case 4:
			System_state = STOP_MONITORING;
			break;
		default:
			menu_displayed = 1;
			break;
		}
	}
}

/* ============================================================
 * Function: Start_Monitoring
 * Purpose : Send "start monitoring" command to Control ECU.
 * ============================================================ */
void Start_Monitoring(void) {
	static uint8 started = 0;
	if(!started) {
		UART_sendByte(1);
		LCD_clearScreen();
		LCD_displayString("Starting!");
		LCD_displayStringRowColumn(1,0,"Monitor Active");
		_delay_ms(1500); /* Spec says 10s, but this is fine  */
		System_state = IDLE;
		started = 1;
	}
	if(System_state != START_OPERATION)
		started = 0;
}

/* ============================================================
 * Function: Display_sensor_data
 * Purpose : Request live sensor data (temperature, distance, window states)
 *           and display on LCD. Automatically times out after 10 seconds.
 * ============================================================ */
void Display_sensor_data(void) {
	static uint8 shown = 0;
	uint8 temp, distance, win1, win2;

	if(!shown) {
		LCD_clearScreen();
		LCD_displayStringRowColumn(0,0,"Live Values");
		shown = 1;
	}
	/*Request Data from control ECU*/
	UART_sendByte(2);
	/* Receive sensor data (with timeout protection) */
	receive_byte_timeout(&temp, 500);
	receive_byte_timeout(&distance, 500);
	receive_byte_timeout(&win1, 500);
	receive_byte_timeout(&win2, 500);

	/* ---- Display readings ---- */
	LCD_displayStringRowColumn(1,0,"Temp:");
	if(temp == UART_RX_TIMEOUT) LCD_displayString("ERR");
	else LCD_intgerToString(temp);
	LCD_displayString("C  ");

	LCD_displayStringRowColumn(2,0,"Dist:");
	if(distance == UART_RX_TIMEOUT) LCD_displayString("ERR");
	else LCD_intgerToString(distance);
	LCD_displayString("cm ");

	/* Show window states as Open/Closed */
	LCD_displayStringRowColumn(3,0,"W1:");
	if(win1 == UART_RX_TIMEOUT) LCD_displayString("?");
	else LCD_displayString(win1 ? "O " : "C ");

	LCD_displayString(" W2:");
	if(win2 == UART_RX_TIMEOUT) LCD_displayString("?");
	else LCD_displayString(win2 ? "O" : "C");

	/*Timeout Handling*/
	if(timeout_flag) {
		timeout_flag = 0; /* Clear the flag */
		shown = 0;        /* Reset header display */
		DisplayAgainPrompt(DISPLAY_VALUES); /*Ask user what he wants to do*/
	}
}

/* ============================================================
 * Function: Send_Logged_Faults
 * Purpose : Retrieve and display logged faults stored in Control ECU EEPROM.
 * ============================================================ */
void Send_Logged_Faults(void) {
	static uint8 once = 0;
	if(!once) {
		/*Send faults command*/
		UART_sendByte(3);
		_delay_ms(100);

		uint8 fault1, fault2;
		receive_byte_timeout(&fault1, 200);
		receive_byte_timeout(&fault2, 200);

		LCD_clearScreen();
		LCD_displayString("Logged Faults:");

		/*Check for UART timeout*/
		if(fault1 == UART_RX_TIMEOUT || fault2 == UART_RX_TIMEOUT) {
			LCD_displayStringRowColumn(1,0, "Comm Timeout!");
		}
		else if (fault1 == 0 && fault2 == 0) {
			LCD_displayStringRowColumn(1,0, "No Faults Logged");
		}
		else {
			/* Display Fault statuses */
			if(fault1 == P001_ACCIDENT_MIGHT_HAPPENED)
				LCD_displayStringRowColumn(1,0,"P001: Dist<10cm");
			else
				LCD_displayStringRowColumn(1,0,"P001: No Fault");


			if(fault2 == P002_ENGINE_HIGH_TEMPERATURE)
				LCD_displayStringRowColumn(2,0,"P002: Overheat");
			else
				LCD_displayStringRowColumn(2,0,"P002: No Fault");
		}
		LCD_displayStringRowColumn(3,0, "--End of List--");
		once = 1;
	}

	/*Timeout Handling*/
	if(timeout_flag) {
		timeout_flag = 0;
		once = 0;
		DisplayAgainPrompt(ERROR_RETRIEVAL);
	}
}

/* ============================================================
 * Function: Stop_Monitoring
 * Purpose : Send command to Control ECU to stop monitoring and return to menu.
 * ============================================================ */
void Stop_Monitoring(void) {
	static uint8 stopped = 0;
	if(!stopped) {
		UART_sendByte(4);
		LCD_clearScreen();
		LCD_displayString("System Monitoring");
		LCD_displayStringRowColumn(1,0,"Stopped!");
		LCD_displayStringRowColumn(2,0,"Returning to Menu...");
		_delay_ms(1500);
		System_state = IDLE;
		stopped = 1;
	}
	if(System_state != STOP_MONITORING)
		stopped = 0;
}

/*---------------- Main Function ----------------*/
int main(void)
{
	SREG |= (1<<7); /* Enable Global Interrupts */
	UART_init(&uart_config);
	LCD_init();
	Timer_setCallBack(Timer_Callback, TIMER1_ID);

	while(1)
	{
		switch(System_state)
		{
		case IDLE:
			HandleIdleState();
			break;
		case START_OPERATION:
			Start_Monitoring();
			break;
		case DISPLAY_VALUES:
			Display_sensor_data();
			break;
		case ERROR_RETRIEVAL:
			Send_Logged_Faults();
			break;
		case STOP_MONITORING:
			Stop_Monitoring();
			break;
		}
		_delay_ms(50);
	}
}
