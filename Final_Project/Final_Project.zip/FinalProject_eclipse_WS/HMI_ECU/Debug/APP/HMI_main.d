APP/HMI_main.o APP/HMI_main.o: ../APP/HMI_main.c \
  ../APP/../MCAL/std_types.h ../APP/../HAL/keypad.h \
  ../APP/../HAL/../MCAL/std_types.h ../APP/../HAL/lcd.h \
  ../APP/../MCAL/uart.h ../APP/../MCAL/std_types.h ../APP/../MCAL/timer.h

../APP/../MCAL/std_types.h:

../APP/../HAL/keypad.h:

../APP/../HAL/../MCAL/std_types.h:

../APP/../HAL/lcd.h:

../APP/../MCAL/uart.h:

../APP/../MCAL/std_types.h:

../APP/../MCAL/timer.h:
