/******************************************************************************
 *
 * Module: TIMER
 *
 * File Name: timer.h
 *
 * Description: Header file for the AVR Timer driver
 *
 * Author: Bavly Maged
 *
 *******************************************************************************/

#ifndef TIMER_H_
#define TIMER_H_

#include "std_types.h"

/*******************************************************************************
 *                         Types Declaration                                   *
 *******************************************************************************/

typedef enum
{
	TIMER0_ID,
	TIMER1_ID,
	TIMER2_ID
} Timer_ID_Type;

/* Timer clock select options */
typedef enum
{
	NO_CLOCK,
	NO_PRESCALING,
	CLK_8,
	CLK_64,
	CLK_256,
	CLK_1024,
	EXT_FALLING,
	EXT_RISING
} Timer_ClockType;

/* Timer mode: Normal or Compare */
typedef enum
{
	TIMER_MODE_NORMAL,
	TIMER_MODE_COMPARE
} Timer_ModeType;

/* Timer configuration structure */
typedef struct
{
	uint16 timer_InitialValue;
	uint16 timer_compare_MatchValue;   /* Used only in compare mode */
	Timer_ID_Type timer_ID;
	Timer_ClockType timer_clock;
	Timer_ModeType timer_mode;
} Timer_ConfigType;

/*******************************************************************************
 *                      Functions Prototypes                                   *
 *******************************************************************************/

/**********************************************************************
 * Description : Function to initialize the Timer driver
 * Argument    : Pointer to the configuration structure
 * Return      : None
 **********************************************************************/
void Timer_init(const Timer_ConfigType * Config_Ptr);

/**********************************************************************
 * Description : Function to disable the Timer via Timer ID
 * Argument    : Timer_ID_Type
 * Return      : None
 **********************************************************************/
void Timer_deInit(Timer_ID_Type timer_type);

/**********************************************************************
 * Description : Function to set the Call Back function address
 * Argument    : Pointer to function + Timer ID
 * Return      : None
 **********************************************************************/
void Timer_setCallBack(void(*a_ptr)(void), Timer_ID_Type a_timer_ID);

#endif /* TIMER_H_ */
