/******************************************************************************
 *
 * Module: UART
 *
 * File Name: uart.h
 *
 * Description: Header file for the UART AVR driver
 *
 * Author: Bavly Maged
 *
 *******************************************************************************/

#ifndef UART_H_
#define UART_H_

#include "std_types.h"

/*******************************************************************************
 *                      Functions Prototypes                                   *
 *******************************************************************************/
typedef enum {
	FIVE_BIT_DATA = 0,
	SIX_BIT_DATA,
	SEVEN_BIT_DATA,
	EIGHT_BIT_DATA,
	NINE_BIT_DATA
}
UART_BitDataType;
typedef enum {
	NO_PARITY = 0,
	EVEN_PARITY,
	ODD_PARITY
}
UART_ParityType;
typedef enum {
	ONE_STOP_BIT = 0,
	TWO_STOP_BIT
}
UART_StopBitType;
typedef enum {

    BAUD_4800,
    BAUD_9600,
    BAUD_14400,
    BAUD_19200,
    BAUD_115200,

}
UART_BaudRateType;


typedef struct {
	UART_BitDataType bit_data;
	UART_ParityType parity;
	UART_StopBitType stop_bit;
	UART_BaudRateType baud_rate;
}UART_ConfigType;
void UART_init(const UART_ConfigType * Config_Ptr);

/*
 * Description :
 * Functional responsible for send byte to another UART device.
 */
void UART_sendByte(const uint8 data);

/*
 * Description :
 * Functional responsible for receive byte from another UART device.
 */
uint8 UART_recieveByte(void);

/*
 * Description :
 * Send the required string through UART to the other UART device.
 */
void UART_sendString(const uint8 *Str);

/*
 * Description :
 * Receive the required string until the '#' symbol through UART from the other UART device.
 */
void UART_receiveString(uint8 *Str); // Receive until #
boolean UART_recieveByteNonBlocking(uint8 *data);
#endif /* UART_H_ */
