/******************************************************************************
 *
 * Module: TIMER
 *
 * File Name: timer.c
 *
 * Description: Source file for the AVR Timer driver
 *
 * Author: Bavly Maged
 *
 *******************************************************************************/

#include "timer.h"
#include <avr/io.h>
#include <avr/interrupt.h>

/*******************************************************************************
 *                           Global Variables                                  *
 *******************************************************************************/

static volatile void (*g_Timer0_callBackPtr)(void) = NULL_PTR;
static volatile void (*g_Timer1_callBackPtr)(void) = NULL_PTR;
static volatile void (*g_Timer2_callBackPtr)(void) = NULL_PTR;

/*******************************************************************************
 *                       Interrupt Service Routines                            *
 *******************************************************************************/

ISR(TIMER0_OVF_vect)
{
	if(g_Timer0_callBackPtr != NULL_PTR)
	{
		(*g_Timer0_callBackPtr)();
	}
}

ISR(TIMER0_COMP_vect)
{
	if(g_Timer0_callBackPtr != NULL_PTR)
	{
		(*g_Timer0_callBackPtr)();
	}
}

ISR(TIMER1_OVF_vect)
{
	if(g_Timer1_callBackPtr != NULL_PTR)
	{
		(*g_Timer1_callBackPtr)();
	}
}

ISR(TIMER1_COMPA_vect)
{
	if(g_Timer1_callBackPtr != NULL_PTR)
	{
		(*g_Timer1_callBackPtr)();
	}
}

ISR(TIMER2_OVF_vect)
{
	if(g_Timer2_callBackPtr != NULL_PTR)
	{
		(*g_Timer2_callBackPtr)();
	}
}

ISR(TIMER2_COMP_vect)
{
	if(g_Timer2_callBackPtr != NULL_PTR)
	{
		(*g_Timer2_callBackPtr)();
	}
}

/*******************************************************************************
 *                       Functions Definitions                                 *
 *******************************************************************************/

void Timer_init(const Timer_ConfigType * Config_Ptr)
{
	switch(Config_Ptr->timer_ID)
	{
	case TIMER0_ID:
		TCNT0 = Config_Ptr->timer_InitialValue;

		if(Config_Ptr->timer_mode == TIMER_MODE_NORMAL)
		{
			TCCR0 = (1<<FOC0); /* Non-PWM */
			TIMSK |= (1<<TOIE0); /* Enable overflow interrupt */
		}
		else if(Config_Ptr->timer_mode == TIMER_MODE_COMPARE)
		{
			TCCR0 = (1<<FOC0) | (1<<WGM01); /* CTC mode */
			OCR0 = Config_Ptr->timer_compare_MatchValue;
			TIMSK |= (1<<OCIE0); /* Enable compare interrupt */
		}

		TCCR0 |= (Config_Ptr->timer_clock & 0x07);
		break;

	case TIMER1_ID:
		TCNT1 = Config_Ptr->timer_InitialValue;

		if(Config_Ptr->timer_mode == TIMER_MODE_NORMAL)
		{
			TCCR1A = (1<<FOC1A);
			TCCR1B = 0x00;
			TIMSK |= (1<<TOIE1);
		}
		else if(Config_Ptr->timer_mode == TIMER_MODE_COMPARE)
		{
			TCCR1A = (1<<FOC1A);
			TCCR1B = (1<<WGM12);
			OCR1A = Config_Ptr->timer_compare_MatchValue;
			TIMSK |= (1<<OCIE1A);
		}

		TCCR1B |= (Config_Ptr->timer_clock & 0x07);
		break;

	case TIMER2_ID:
		TCNT2 = Config_Ptr->timer_InitialValue;

		if(Config_Ptr->timer_mode == TIMER_MODE_NORMAL)
		{
			TCCR2 = (1<<FOC2);
			TIMSK |= (1<<TOIE2);
		}
		else if(Config_Ptr->timer_mode == TIMER_MODE_COMPARE)
		{
			TCCR2 = (1<<FOC2) | (1<<WGM21);
			OCR2 = Config_Ptr->timer_compare_MatchValue;
			TIMSK |= (1<<OCIE2);
		}

		TCCR2 |= (Config_Ptr->timer_clock & 0x07);
		break;
	}
}

void Timer_deInit(Timer_ID_Type timer_type)
{
	switch(timer_type)
	{
	case TIMER0_ID:
		TCCR0 = 0;
		TCNT0 = 0;
		OCR0  = 0;
		TIMSK &= ~((1<<TOIE0) | (1<<OCIE0));
		break;

	case TIMER1_ID:
		TCCR1A = 0;
		TCCR1B = 0;
		TCNT1  = 0;
		OCR1A  = 0;
		TIMSK &= ~((1<<TOIE1) | (1<<OCIE1A));
		break;

	case TIMER2_ID:
		TCCR2 = 0;
		TCNT2 = 0;
		OCR2  = 0;
		TIMSK &= ~((1<<TOIE2) | (1<<OCIE2));
		break;
	}
}

void Timer_setCallBack(void(*a_ptr)(void), Timer_ID_Type a_timer_ID)
{
	switch(a_timer_ID)
	{
	case TIMER0_ID:
		g_Timer0_callBackPtr = a_ptr;
		break;
	case TIMER1_ID:
		g_Timer1_callBackPtr = a_ptr;
		break;
	case TIMER2_ID:
		g_Timer2_callBackPtr = a_ptr;
		break;
	}
}
