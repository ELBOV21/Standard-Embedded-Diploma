/* ============================================================
 *  CONTROL_ECU.c
 *  ------------------------------------------------------------
 *  Control ECU code for Vehicle Fault Detection and Logging System
 *  Microcontroller: ATmega32 @ 8MHz
 *
 *  - Reads data from temperature (LM35) and distance (ultrasonic) sensors
 *  - Controls two DC motors (representing windows)
 *  - Detects and logs vehicle faults in External EEPROM
 *  - Communicates with HMI ECU via UART
 * ============================================================ */

#include"../HAL/lm35_sensor.h"
#include"../HAL/dc_motor.h"
#include"../HAL/external_eeprom.h"
#include"../HAL/ultrasonic.h"
#include "../MCAL/twi.h"
#include "../MCAL/std_types.h"
#include "../MCAL/uart.h"
#include "../HAL/led.h"
#include "../HAL/push_button.h"
#include <avr/io.h>
#include <util/delay.h>

/* ====================== ERROR CODES ====================== */
#define P001_ACCIDENT_MIGHT_HAPPENED 0x01 /*Error for accident detection*/
#define P002_ENGINE_HIGH_TEMPERATURE 0x02 /*Error for engine overheating*/
/* ====================== EEPROM ADDRESSES ====================== */
#define P001_ADDRESS 0x0001
#define P002_ADDRESS 0x0002

/* ====================== GLOBAL VARIABLES ====================== */
uint8 distance = 0;          /* Distance from ultrasonic sensor*/
uint8 temp = 0;              /* Temperature from LM35 sensor*/
uint8 win1 = 0;              /* Window 1 state (1 = open, 0 = closed)*/
uint8 win2 = 0;              /* Window 2 state (1 = open, 0 = closed)*/
uint8 command = 0;           /* Received UART command from HMI ECU*/
uint8 monitoring_flag = 0;   /* Enables/disables live monitoring mode*/
uint8 p001_occurred = 0;     /* Prevents logging same accident event multiple times*/
uint8 p002_occurred = 0;     /* Prevents logging same temperature event multiple times*/
uint8 fault1 = 0;            /* Holds fault code read from EEPROM (accident)*/
uint8 fault2 = 0;            /* Holds fault code read from EEPROM (temperature)*/


/* ============================================================
 * Function: UltraSonic_Handle
 * Purpose : Read distance and log fault if object < 10 cm
 * ============================================================ */
void UltraSonic_Handle(void) {

	distance = Ultrasonic_readDistance();
	/* Log accident if distance too small and error not logged before */
	if(distance < 10 && !p001_occurred) {
		EEPROM_writeByte(P001_ADDRESS, P001_ACCIDENT_MIGHT_HAPPENED);
		_delay_ms(20);
		p001_occurred = 1;
	}
}

/* ============================================================
 * Function: Temperature_Handle
 * Purpose : Read temperature and log high-temp fault if > 90°C
 * ============================================================ */
void Temperatue_Handle(void) {
	temp = LM35_getTemperature();
	/* Activate fault if high temperature detected and error not logged before*/
	if(temp > 90 && !p002_occurred) {
		EEPROM_writeByte(P002_ADDRESS, P002_ENGINE_HIGH_TEMPERATURE);
		_delay_ms(20);
		p002_occurred = 1;
	}
}

/* ============================================================
 * Function: HandleMotors
 * Purpose : Control DC motors based on push buttons
 * ============================================================ */
void HandleMotors(void) {
	/* Window 1 Control */
	if(BUTTON_getState(BUTTON1) == LOGIC_HIGH) {
		DcMotor_Rotate(MOTOR_A, CCW, 255); /*Open Window 1*/
		win1 = 1;
	} else if(BUTTON_getState(BUTTON2) == LOGIC_HIGH) {
		DcMotor_Rotate(MOTOR_A, STOP, 0);  /*Close Window 1*/
		win1 = 0;
	}

	/* Window 2 Control */
	if(BUTTON_getState(BUTTON3) == LOGIC_HIGH) {
		DcMotor_Rotate(MOTOR_B, CCW, 255); /*Open Window 2*/
		win2 = 1;
	} else if(BUTTON_getState(BUTTON4) == LOGIC_HIGH) {
		DcMotor_Rotate(MOTOR_B, STOP, 0);  /*Close Window 2*/
		win2 = 0;
	}
}

/* ============================================================
 * Function: uart_receive_command_nonblocking
 * Purpose : Try receiving UART command without blocking
 * Returns : 1 if command received, 0 otherwise
 * ============================================================ */
uint8 uart_receive_command_nonblocking(uint8 *cmd) {
	return UART_recieveByteNonBlocking(cmd);
}

int main(void)
{
	SREG |= (1<<7); /*Enable Global Interrupts*/


	/* ========== Initialize all peripherals ========== */
	TWI_ConfigType twi_config = {0x01, TWI_PRESCALER_1};
	TWI_init(&twi_config);

	UART_ConfigType uart_config = {EIGHT_BIT_DATA, NO_PARITY, ONE_STOP_BIT, BAUD_9600};
	UART_init(&uart_config);

	LM35_init();
	Ultrasonic_init();
	LEDS_init();


	DcMotor_Init();
	BUTTON_init();

/*
	 EEPROM_writeByte(P001_ADDRESS, 0);
	 _delay_ms(20);
	 EEPROM_writeByte(P002_ADDRESS, 0);
	 _delay_ms(20);
*/
	while(1)
	{
		/* Check if any UART command received */
		if(uart_receive_command_nonblocking(&command)) {
			switch(command)
			{
			case 1: /* Start Monitoring Mode */
				monitoring_flag = 1;
				p001_occurred = 0;
				p002_occurred = 0;
				break;

			case 2:/* Send Live Sensor Data to HMI */
				UART_sendByte(temp);
				UART_sendByte(distance);
				UART_sendByte(win1);
				UART_sendByte(win2);

				break;

			case 3: /* Send Fault Codes Stored in EEPROM */
				EEPROM_readByte(P001_ADDRESS, &fault1);
				_delay_ms(10);
				EEPROM_readByte(P002_ADDRESS, &fault2);
				_delay_ms(10);
				UART_sendByte(fault1);
				_delay_ms(5);
				UART_sendByte(fault2);
				_delay_ms(5);
				break;

			case 4: /* Stop Monitoring Mode */
				monitoring_flag = 0;
				p001_occurred = 0;
				p002_occurred = 0;
				break;
			default:
				/* ignore unknown commands*/
				break;
			}
		}

		/* ========== Perform Monitoring Tasks ========== */
		if(monitoring_flag) {
			UltraSonic_Handle();
			Temperatue_Handle();
			HandleMotors();
		}
		_delay_ms(50);
	}
	return 0;
}
