APP/main.o APP/main.o: ../APP/main.c ../APP/../HAL/lm35_sensor.h \
  ../APP/../HAL/../MCAL/std_types.h ../APP/../HAL/../MCAL/adc.h \
  ../APP/../HAL/../MCAL/std_types.h ../APP/../HAL/../MCAL/common_macros.h \
  ../APP/../HAL/dc_motor.h ../APP/../HAL/../MCAL/common_macros.h \
  ../APP/../HAL/../MCAL/pwm.h ../APP/../HAL/external_eeprom.h \
  ../APP/../HAL/ultrasonic.h ../APP/../MCAL/twi.h \
  ../APP/../MCAL/std_types.h ../APP/../MCAL/std_types.h \
  ../APP/../MCAL/uart.h ../APP/../HAL/led.h ../APP/../HAL/../MCAL/gpio.h \
  ../APP/../HAL/push_button.h

../APP/../HAL/lm35_sensor.h:

../APP/../HAL/../MCAL/std_types.h:

../APP/../HAL/../MCAL/adc.h:

../APP/../HAL/../MCAL/std_types.h:

../APP/../HAL/../MCAL/common_macros.h:

../APP/../HAL/dc_motor.h:

../APP/../HAL/../MCAL/common_macros.h:

../APP/../HAL/../MCAL/pwm.h:

../APP/../HAL/external_eeprom.h:

../APP/../HAL/ultrasonic.h:

../APP/../MCAL/twi.h:

../APP/../MCAL/std_types.h:

../APP/../MCAL/std_types.h:

../APP/../MCAL/uart.h:

../APP/../HAL/led.h:

../APP/../HAL/../MCAL/gpio.h:

../APP/../HAL/push_button.h:
