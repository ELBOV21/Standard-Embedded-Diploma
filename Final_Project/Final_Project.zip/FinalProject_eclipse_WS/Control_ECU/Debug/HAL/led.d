HAL/led.o HAL/led.o: ../HAL/led.c ../HAL/led.h ../HAL/../MCAL/gpio.h \
  ../HAL/../MCAL/std_types.h ../HAL/../MCAL/std_types.h \
  ../HAL/../MCAL/common_macros.h

../HAL/led.h:

../HAL/../MCAL/gpio.h:

../HAL/../MCAL/std_types.h:

../HAL/../MCAL/std_types.h:

../HAL/../MCAL/common_macros.h:
