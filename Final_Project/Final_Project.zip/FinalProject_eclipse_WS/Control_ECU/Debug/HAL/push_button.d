HAL/push_button.o HAL/push_button.o: ../HAL/push_button.c \
  ../HAL/push_button.h ../HAL/../MCAL/gpio.h ../HAL/../MCAL/std_types.h \
  ../HAL/../MCAL/std_types.h ../HAL/../MCAL/common_macros.h

../HAL/push_button.h:

../HAL/../MCAL/gpio.h:

../HAL/../MCAL/std_types.h:

../HAL/../MCAL/std_types.h:

../HAL/../MCAL/common_macros.h:
