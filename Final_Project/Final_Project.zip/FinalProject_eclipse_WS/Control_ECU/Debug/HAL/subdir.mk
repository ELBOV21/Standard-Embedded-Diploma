################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../HAL/dc_motor.c \
../HAL/external_eeprom.c \
../HAL/led.c \
../HAL/lm35_sensor.c \
../HAL/push_button.c \
../HAL/ultrasonic.c 

OBJS += \
./HAL/dc_motor.o \
./HAL/external_eeprom.o \
./HAL/led.o \
./HAL/lm35_sensor.o \
./HAL/push_button.o \
./HAL/ultrasonic.o 

C_DEPS += \
./HAL/dc_motor.d \
./HAL/external_eeprom.d \
./HAL/led.d \
./HAL/lm35_sensor.d \
./HAL/push_button.d \
./HAL/ultrasonic.d 


# Each subdirectory must supply rules for building sources it contributes
HAL/%.o: ../HAL/%.c HAL/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: AVR Compiler'
	avr-gcc -Wall -g2 -gstabs -O0 -fpack-struct -fshort-enums -ffunction-sections -fdata-sections -std=gnu99 -funsigned-char -funsigned-bitfields -mmcu=atmega32 -DF_CPU=8000000UL -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


