/******************************************************************************
 *
 * Module: Push Button
 *
 * File Name: push_button.h
 *
 * Description: Header file for the Push Button driver
 *
 * Author: Bavly Maged
 *
 ******************************************************************************/

#ifndef HAL_PUSH_BUTTON_H_
#define HAL_PUSH_BUTTON_H_

#include "../MCAL/gpio.h"
#include "../MCAL/std_types.h"
#include "../MCAL/common_macros.h"

/*******************************************************************************
 *                                Definitions                                  *
 *******************************************************************************/

/* Push Buttons Port Configuration */
#define BUTTON1_PORT_ID   PORTC_ID
#define BUTTON2_PORT_ID   PORTC_ID
#define BUTTON3_PORT_ID   PORTC_ID
#define BUTTON4_PORT_ID   PORTC_ID

/* Push Buttons Pin Configuration */
#define BUTTON1_PIN_ID    PIN7_ID
#define BUTTON2_PIN_ID    PIN6_ID
#define BUTTON3_PIN_ID    PIN5_ID
#define BUTTON4_PIN_ID    PIN4_ID

/* Connection type: choose PULL_UP or PULL_DOWN */
#define BUTTON_CONNECTION_TYPE  PULL_UP

/*******************************************************************************
 *                                Enums                                         *
 *******************************************************************************/

typedef enum
{
	BUTTON1,
	BUTTON2,
	BUTTON3,
	BUTTON4
}BUTTON_ID;

/*******************************************************************************
 *                                Functions Prototypes                          *
 *******************************************************************************/

/*
 * Function used to setup button pins as inputs
 * and enable internal pull-up if selected
 */
void BUTTON_init(void);

/*
 * Function returns the current state of a specific button
 * (pressed or not pressed)
 */
uint8 BUTTON_getState(BUTTON_ID id);

#endif /* HAL_PUSH_BUTTON_H_ */
