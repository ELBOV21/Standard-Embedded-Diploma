#include "dc_motor.h"
#include "../MCAL/gpio.h"

/*******************************************************************************
 *                      Functions Definitions                                  *
 *******************************************************************************/

void DcMotor_Init(void)
{
	/* Motor A pins */
	GPIO_setupPinDirection(MOTOR_A_IN1_PORT_ID, MOTOR_A_IN1_PIN_ID, PIN_OUTPUT);
	GPIO_setupPinDirection(MOTOR_A_IN2_PORT_ID, MOTOR_A_IN2_PIN_ID, PIN_OUTPUT);
	GPIO_setupPinDirection(MOTOR_A_EN_PORT_ID, MOTOR_A_EN_PIN_ID, PIN_OUTPUT);

	/* Motor B pins */
	GPIO_setupPinDirection(MOTOR_B_IN1_PORT_ID, MOTOR_B_IN1_PIN_ID, PIN_OUTPUT);
	GPIO_setupPinDirection(MOTOR_B_IN2_PORT_ID, MOTOR_B_IN2_PIN_ID, PIN_OUTPUT);
	GPIO_setupPinDirection(MOTOR_B_EN_PORT_ID, MOTOR_B_EN_PIN_ID, PIN_OUTPUT);

	/* Initially stop both motors */
	GPIO_writePin(MOTOR_A_IN1_PORT_ID, MOTOR_A_IN1_PIN_ID, LOGIC_LOW);
	GPIO_writePin(MOTOR_A_IN2_PORT_ID, MOTOR_A_IN2_PIN_ID, LOGIC_LOW);
	GPIO_writePin(MOTOR_B_IN1_PORT_ID, MOTOR_B_IN1_PIN_ID, LOGIC_LOW);
	GPIO_writePin(MOTOR_B_IN2_PORT_ID, MOTOR_B_IN2_PIN_ID, LOGIC_LOW);

	/* Initialize PWM for motor control */
	PWM_Timer0_Start(0); /* Assume PWM0 controls Motor A */

}

void DcMotor_Rotate(DCMotor_ID id, DCMotor_state state, uint8 speed)
{
	switch(id)
	{
	case MOTOR_A:
		switch(state)
		{
		case STOP:
			GPIO_writePin(MOTOR_A_IN1_PORT_ID, MOTOR_A_IN1_PIN_ID, LOGIC_LOW);
			GPIO_writePin(MOTOR_A_IN2_PORT_ID, MOTOR_A_IN2_PIN_ID, LOGIC_LOW);
			break;

		case CW:
			GPIO_writePin(MOTOR_A_IN1_PORT_ID, MOTOR_A_IN1_PIN_ID, LOGIC_HIGH);
			GPIO_writePin(MOTOR_A_IN2_PORT_ID, MOTOR_A_IN2_PIN_ID, LOGIC_LOW);
			break;

		case CCW:
			GPIO_writePin(MOTOR_A_IN1_PORT_ID, MOTOR_A_IN1_PIN_ID, LOGIC_LOW);
			GPIO_writePin(MOTOR_A_IN2_PORT_ID, MOTOR_A_IN2_PIN_ID, LOGIC_HIGH);
			break;
		}
		PWM_Timer0_Start(speed);  /* PWM controls Motor A speed */
		break;

	case MOTOR_B:
		switch(state)
		{
		case STOP:
			GPIO_writePin(MOTOR_B_IN1_PORT_ID, MOTOR_B_IN1_PIN_ID, LOGIC_LOW);
			GPIO_writePin(MOTOR_B_IN2_PORT_ID, MOTOR_B_IN2_PIN_ID, LOGIC_LOW);
			break;

		case CW:
			GPIO_writePin(MOTOR_B_IN1_PORT_ID, MOTOR_B_IN1_PIN_ID, LOGIC_HIGH);
			GPIO_writePin(MOTOR_B_IN2_PORT_ID, MOTOR_B_IN2_PIN_ID, LOGIC_LOW);
			break;

		case CCW:
			GPIO_writePin(MOTOR_B_IN1_PORT_ID, MOTOR_B_IN1_PIN_ID, LOGIC_LOW);
			GPIO_writePin(MOTOR_B_IN2_PORT_ID, MOTOR_B_IN2_PIN_ID, LOGIC_HIGH);
			break;
		}
		PWM_Timer0_Start(speed);  /* PWM controls Motor B speed */
		break;
	}
}
