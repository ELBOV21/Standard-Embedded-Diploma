/******************************************************************************
 *
 * Module: Push Button
 *
 * File Name: push_button.c
 *
 * Description: Source file for the Push Button driver
 *
 * Author: Bavly Maged
 *
 ******************************************************************************/

#include "push_button.h"

/*
 * Description:
 * Initialize all push buttons as inputs
 * Enable internal pull-up resistors if selected
 */
void BUTTON_init(void)
{
#if (BUTTON_CONNECTION_TYPE == PULL_UP)
	/* Configure buttons as input and enable internal pull-up resistors */
	GPIO_setupPinDirection(BUTTON1_PORT_ID, BUTTON1_PIN_ID, PIN_INPUT);
	GPIO_setupPinDirection(BUTTON2_PORT_ID, BUTTON2_PIN_ID, PIN_INPUT);
	GPIO_setupPinDirection(BUTTON3_PORT_ID, BUTTON3_PIN_ID, PIN_INPUT);
	GPIO_setupPinDirection(BUTTON4_PORT_ID, BUTTON4_PIN_ID, PIN_INPUT);

	GPIO_writePin(BUTTON1_PORT_ID, BUTTON1_PIN_ID, LOGIC_HIGH);
	GPIO_writePin(BUTTON2_PORT_ID, BUTTON2_PIN_ID, LOGIC_HIGH);
	GPIO_writePin(BUTTON3_PORT_ID, BUTTON3_PIN_ID, LOGIC_HIGH);
	GPIO_writePin(BUTTON4_PORT_ID, BUTTON4_PIN_ID, LOGIC_HIGH);

#elif (BUTTON_CONNECTION_TYPE == PULL_DOWN)
	/* Configure buttons as input (no pull-up) */
	GPIO_setupPinDirection(BUTTON1_PORT_ID, BUTTON1_PIN_ID, PIN_INPUT);
	GPIO_setupPinDirection(BUTTON2_PORT_ID, BUTTON2_PIN_ID, PIN_INPUT);
	GPIO_setupPinDirection(BUTTON3_PORT_ID, BUTTON3_PIN_ID, PIN_INPUT);
	GPIO_setupPinDirection(BUTTON4_PORT_ID, BUTTON4_PIN_ID, PIN_INPUT);
#endif
}

/*
 * Description:
 * Read and return the current state of the selected button
 */
uint8 BUTTON_getState(BUTTON_ID id)
{
	uint8 state = LOGIC_LOW;

	switch(id)
	{
	case BUTTON1:
		state = GPIO_readPin(BUTTON1_PORT_ID, BUTTON1_PIN_ID);
		break;

	case BUTTON2:
		state = GPIO_readPin(BUTTON2_PORT_ID, BUTTON2_PIN_ID);
		break;

	case BUTTON3:
		state = GPIO_readPin(BUTTON3_PORT_ID, BUTTON3_PIN_ID);
		break;

	case BUTTON4:
		state = GPIO_readPin(BUTTON4_PORT_ID, BUTTON4_PIN_ID);
		break;
	}

#if (BUTTON_CONNECTION_TYPE == PULL_UP)
	/* In pull-up connection, pressed = 0 */
	if(state == LOGIC_LOW)
	{
		return LOGIC_HIGH; /* Pressed */
	}
	else
	{
		return LOGIC_LOW;  /* Not pressed */
	}
#elif (BUTTON_CONNECTION_TYPE == PULL_DOWN)
	/* In pull-down connection, pressed = 1 */
	return state;
#endif
}
