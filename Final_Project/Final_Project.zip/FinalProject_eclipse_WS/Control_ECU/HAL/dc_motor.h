/******************************************************************************
 *
 * Module: DC Motors
 *
 * File Name: dc_motor.h
 *
 * Description: Header file for dc motor driver
 *
 * Author: Bavly Maged
 *
 *******************************************************************************/

#ifndef HAL_DC_MOTOR_H_
#define HAL_DC_MOTOR_H_

#include "../MCAL/std_types.h"
#include "../MCAL/common_macros.h"
#include "../MCAL/pwm.h"

/*******************************************************************************
 *                                Definitions                                  *
 *******************************************************************************/

/* ---------------- MOTOR A Configuration ---------------- */
#define MOTOR_A_IN1_PORT_ID   PORTA_ID
#define MOTOR_A_IN2_PORT_ID   PORTA_ID
#define MOTOR_A_IN1_PIN_ID    PIN7_ID
#define MOTOR_A_IN2_PIN_ID    PIN6_ID
#define MOTOR_A_EN_PORT_ID    PORTB_ID
#define MOTOR_A_EN_PIN_ID     PIN3_ID   /* Enable pin for Motor A */

/* ---------------- MOTOR B Configuration ---------------- */
#define MOTOR_B_IN1_PORT_ID   PORTA_ID
#define MOTOR_B_IN2_PORT_ID   PORTA_ID
#define MOTOR_B_IN1_PIN_ID    PIN4_ID
#define MOTOR_B_IN2_PIN_ID    PIN3_ID
#define MOTOR_B_EN_PORT_ID    PORTB_ID
#define MOTOR_B_EN_PIN_ID     PIN3_ID   /* Enable pin for Motor B */

/*******************************************************************************
 *                                Enums                                         *
 *******************************************************************************/

typedef enum {
	MOTOR_A,
	MOTOR_B
}DCMotor_ID;

typedef enum {
	STOP,
	CW,
	CCW
}DCMotor_state;

/*******************************************************************************
 *                                Function Prototypes                           *
 *******************************************************************************/

/* Description:
 * Initialize both motors:
 * - Set direction pins as output
 * - Set enable pins as output
 * - Set initial state as STOP
 */
void DcMotor_Init(void);

/* Description:
 * Rotate the selected motor in the specified direction and speed (0–100%).
 */
void DcMotor_Rotate(DCMotor_ID id, DCMotor_state state, uint8 speed);

#endif /* HAL_DC_MOTOR_H_ */
